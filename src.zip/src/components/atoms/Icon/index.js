import {RiArrowDropDownLine} from "react-icons/ri";

const DropDownIcon = () => {
    return (
        <RiArrowDropDownLine>Explore</RiArrowDropDownLine>
    );
}

export default DropDownIcon;